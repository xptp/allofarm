import { useEffect, useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import './styles/global.css';

const copy = {
  ru: {
    descriptor: 'Биотехнологическая компания', nav: ['Главная', 'О компании', 'Наши разработки', 'Публикации', 'Пресс-центр', 'Контакты'],
    menu: 'Открыть меню', close: 'Закрыть меню', eyebrow: 'Биомиметика иммунной системы насекомых',
    title: <>АЛЛОФАРМ<br /><span>Биотехнологическая компания</span></>,
    slides: ['Антимикробные и противоопухолевые средства нового поколения на основе природных пептидов врождённого иммунитета.', 'Настоящие биотехнологии: химический пептидный синтез и замкнутый цикл культивирования биомассы.', 'Миллионы лет эволюции в вашей аптечке: биомиметика защитных механизмов насекомых.'],
    metrics: [['20+ лет', 'Фундаментальных исследований'], ['Web of Science', 'Публикации PNAS и PLOS ONE'], ['Патентная база', 'Патенты в России и за рубежом']],
    primary: 'О нашей компании', secondary: 'Наши разработки', imageAlt: 'Схематичное изображение насекомого и пептидной структуры',
    location: 'Санкт-Петербург, Россия', address: 'Санкт-Петербург, пр-т Малый В.О., д. 57, корп. 4/Ж', langLabel: 'Выбрать язык',
    pageTitle: 'Аллофарм — биотехнологическая компания', pageDescription: 'Аллофарм — биотехнологическая компания. Разработка новых лекарственных веществ на основе активных компонентов иммунной системы насекомых.',
  },
  en: {
    descriptor: 'Biotechnology company', nav: ['Home', 'About us', 'Developments', 'Publications', 'Press centre', 'Contacts'],
    menu: 'Open menu', close: 'Close menu', eyebrow: 'Biomimetics of the insect immune system',
    title: <>ALLOPHARM<br /><span>Biotechnology company</span></>,
    slides: ['Next-generation antimicrobial and antitumour agents based on natural peptides of innate immunity.', 'Real biotechnology: chemical peptide synthesis and a closed cycle of biomass cultivation.', 'Millions of years of evolution: biomimetics of the protective mechanisms of insects.'],
    metrics: [['20+ years', 'Fundamental research'], ['Web of Science', 'Publications in PNAS and PLOS ONE'], ['Patent portfolio', 'Patents in Russia and internationally']],
    primary: 'About our company', secondary: 'Our developments', imageAlt: 'Schematic illustration of an insect and peptide structure',
    location: 'Saint Petersburg, Russia', address: '57 Maliy Prospect V.O., Saint Petersburg', langLabel: 'Choose language',
    pageTitle: 'Allopharm — biotechnology company', pageDescription: 'Allopharm is a biotechnology company developing new medicinal substances based on active components of the insect immune system.',
  },
};

const destinations = {
  ru: ['/', 'https://allopharm.ru/about/', 'https://allopharm.ru/allostatins/', 'https://allopharm.ru/our-publications/', 'https://allopharm.ru/', 'https://allopharm.ru/contact/'],
  en: ['/', 'https://en.allopharm.ru/about/', 'https://en.allopharm.ru/allostatins/', 'https://en.allopharm.ru/our-publications/', 'https://en.allopharm.ru/', 'https://en.allopharm.ru/contact/'],
};

function App() {
  const [language, setLanguage] = useState('ru');
  const t = copy[language];
  useEffect(() => { document.documentElement.lang = language; }, [language]);

  return (
    <div className="site-shell">
      <title>{t.pageTitle}</title>
      <meta name="description" content={t.pageDescription} />
      <Header language={language} onLanguageChange={setLanguage} t={t} links={destinations[language]} />
      <Home language={language} t={t} links={destinations[language]} />
      <Footer language={language} t={t} links={destinations[language]} />
    </div>
  );
}

export default App;
