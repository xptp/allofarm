import footerLogo from '../assets/logo-header.png';
import '../styles/Footer.css';

const footerCopy = {
  ru: {
    description: 'Разработка и внедрение оригинальных фармацевтических субстанций на основе молекулярных факторов иммунной системы насекомых.',
    navigation: 'Навигация',
    platforms: 'Платформы',
    contacts: 'Контакты',
    office: 'Адрес офиса и лабораторий:',
    phone: 'Телефон:',
    email: 'Email:',
    collaboration: 'Научное сотрудничество: открыты к диалогу',
    privacy: 'Политика конфиденциальности',
    copyright: `© 2003–${new Date().getFullYear()} Аллофарм. Все права защищены. Инновационная пептидная биотехнология.`,
    city: 'Санкт-Петербург, Россия',
    tagline: 'Биотехнология и R&D',
    platformsList: ['АЛЛОСТАТИН®', 'FLIP®7 Комплекс', 'InOVA-C & Адъювант', 'Аллофероны', 'Calliphoridae Tech'],
  },
  en: {
    description: 'Development and implementation of original pharmaceutical substances based on molecular factors of the insect immune system.',
    navigation: 'Navigation',
    platforms: 'Platforms',
    contacts: 'Contacts',
    office: 'Office and laboratory address:',
    phone: 'Phone:',
    email: 'Email:',
    collaboration: 'Research partnerships: open to collaboration',
    privacy: 'Privacy policy',
    copyright: `© 2003–${new Date().getFullYear()} Allopharm. All rights reserved. Innovative peptide biotechnology.`,
    city: 'Saint Petersburg, Russia',
    tagline: 'Biotechnology & R&D',
    platformsList: ['ALLOSTATIN®', 'FLIP®7 Complex', 'InOVA-C & Adjuvant', 'Alloferons', 'Calliphoridae Tech'],
  },
};

function Footer({ language, t, links }) {
  const copy = footerCopy[language];
  const platformNames = copy.platformsList;

  return (
    <footer className="site-footer">
      <div className="footer-container">
        <div className="footer-main">
          <section className="footer-company" aria-label={language === 'ru' ? 'О компании' : 'About the company'}>
            <a className="footer-brand" href="/" aria-label={language === 'ru' ? 'Аллофарм — главная' : 'Allopharm — home'}>
              <img src={footerLogo} alt="АЛЛОФАРМ — биотехнологическая компания" />
            </a>
            <p>{copy.description}</p>
            <p className="footer-legal">{language === 'ru' ? 'ООО «Аллофарм»' : 'Allopharm LLC'}<br />{language === 'ru' ? 'ОГРН' : 'Registration No.'}: 1047800031663<br />{language === 'ru' ? 'ИНН' : 'Tax ID'}: 7801265876</p>
            <span className="footer-privacy">{copy.privacy}</span>
          </section>

          <nav className="footer-column" aria-label={copy.navigation}>
            <h2>{copy.navigation}</h2>
            {t.nav.map((label, index) => <a href={links[index]} key={label}>{label}</a>)}
          </nav>

          <nav className="footer-column" aria-label={copy.platforms}>
            <h2>{copy.platforms}</h2>
            {platformNames.map((name) => <a href={`${links[2]}#developments-title`} key={name}>{name}</a>)}
          </nav>

          <section className="footer-column footer-contacts" aria-label={copy.contacts}>
            <h2>{copy.contacts}</h2>
            <p><strong>{copy.office}</strong><br />{t.address}</p>
            <p><strong>{copy.phone}</strong> <a href="tel:+79315923375">+7 (931) 592-33-75</a><br /><strong>{copy.phone}</strong> <a href="tel:+78123205542">+7 (812) 320-55-42</a></p>
            <p><strong>{copy.email}</strong> <a className="footer-email" href="mailto:allofarm.spb@yandex.ru">allofarm.spb@yandex.ru</a></p>
            <a className="footer-collaboration" href="mailto:allofarm.spb@yandex.ru">{copy.collaboration}</a>
          </section>
        </div>

        <div className="footer-bottom">
          <p>{copy.copyright}</p>
          <div><span>{copy.city}</span><span className="footer-separator" aria-hidden="true">•</span><span>{copy.tagline}</span></div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
