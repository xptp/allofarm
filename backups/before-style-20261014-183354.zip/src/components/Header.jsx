import { useState } from 'react';
import headerLogo from '../assets/logo-header.png';
import '../styles/Header.css';

function Header({ language, onLanguageChange, t, links }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const changeLanguage = (nextLanguage) => {
    onLanguageChange(nextLanguage);
    setMenuOpen(false);
  };

  return (
    <header className="site-header">
      <div className="utility-bar">
        <div className="header-container utility-inner">
          <span className="utility-address">{t.address}</span>
          <a href="tel:+78123205542">+7 (812) 320-55-42</a>
          <a href="mailto:allofarm.spb@yandex.ru">allofarm.spb@yandex.ru</a>
          <div className="language-switch" role="group" aria-label={t.langLabel}>
            {['ru', 'en'].map((lang, index) => <span className="language-option" key={lang}>
              {index > 0 && <span className="language-divider" aria-hidden="true">/</span>}
              <button type="button" className={language === lang ? 'language-button active' : 'language-button'} aria-pressed={language === lang} onClick={() => changeLanguage(lang)}>{lang.toUpperCase()}</button>
            </span>)}
          </div>
        </div>
      </div>
      <div className="header-container main-header">
        <a className="brand" href="/" aria-label={language === 'ru' ? 'Аллофарм — главная' : 'Allopharm — home'}>
          <img src={headerLogo} alt="АЛЛОФАРМ" />
        </a>
        <button className="menu-toggle" type="button" aria-expanded={menuOpen} aria-label={menuOpen ? t.close : t.menu} onClick={() => setMenuOpen((open) => !open)}>
          <span /><span /><span />
        </button>
        <nav className={menuOpen ? 'primary-nav open' : 'primary-nav'} aria-label={language === 'ru' ? 'Основная навигация' : 'Main navigation'}>
          {t.nav.map((label, i) => <a key={label} className={i === 0 ? 'current' : ''} href={links[i]} onClick={() => setMenuOpen(false)}>{label}<span className="nav-arrow" aria-hidden="true">↗</span></a>)}
        </nav>
      </div>
    </header>
  );
}

export default Header;
